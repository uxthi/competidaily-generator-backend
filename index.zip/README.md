# competidaily-generator-backend
Competidaily Generator backend lambda functions.
